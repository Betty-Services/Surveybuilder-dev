import { fetchOne, createMany, getAllRecords } from "../../helpers/queries.js";

const CreateSubmissionInteractions = async ({
  submissionToken,
  questions,
  answerOptions,
  log,
}) => {};

export default CreateSubmissionInteractions;
